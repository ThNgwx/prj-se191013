/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pe.model;

/**
 *
 * @author Computing Fundamental - HCM Campus
 */
public class UserDao {
    //-----            your code here   --------------------------------
//        public UserDto checkLogin(String username, String password) {
//        if ("admin".equals(username) && "123".equals(password)) {
//            return new UserDto(username, password);
//        }
//        return null;
//    }
}
